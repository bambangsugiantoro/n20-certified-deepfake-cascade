#!/bin/bash
# Download public Google Drive items without login (gdown). Retries on Drive quota errors.
# Usage: dl_gdrive.sh <folder|file> <url> <outdir>
set -u
KIND=$1; URL=$2; OUT=$3; mkdir -p "$OUT"
R=/virtiofs/work/bambang/cascade; PY="apptainer exec $R/env/pytorch.sif $R/env/venv/bin/python -m gdown"
for a in $(seq 1 12); do
  if [ "$KIND" = folder ]; then $PY --folder "$URL" -O "$OUT" --remaining-ok --continue && break
  else (cd "$OUT" && $PY "$URL" --continue) && break; fi
  echo "attempt $a failed for $URL; retry in 20 min"; sleep 1200
done
echo "== $OUT"; du -sh "$OUT"; find "$OUT" -type f | wc -l
