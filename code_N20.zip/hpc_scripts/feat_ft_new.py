"""Penultimate features of the fine-tuned face tiers for shards that have no features yet (e.g. face_dr_*).
Usage: feat_ft_new.py <timm_name> <name>   (loads models/<name>.pt; writes feats/face/<cond>/<name>/<shard>.npz)"""
import os, sys, io, glob, tarfile, time
import numpy as np, torch, timm
from PIL import Image
R = "/virtiofs/work/bambang/cascade"; TIMM, NAME = sys.argv[1], sys.argv[2]; dev = "cuda"
MEAN = torch.tensor([0.485, 0.456, 0.406]).view(3, 1, 1); STD = torch.tensor([0.229, 0.224, 0.225]).view(3, 1, 1)
class Eval(torch.utils.data.Dataset):
    def __init__(self, items): self.items = items
    def __len__(self): return len(self.items)
    def __getitem__(self, i):
        im = Image.open(io.BytesIO(self.items[i][1])).convert("RGB").resize((224, 224), Image.BICUBIC)
        x = torch.from_numpy(np.asarray(im, dtype=np.uint8).copy()).permute(2, 0, 1).float() / 255.
        return (x - MEAN) / STD
m = timm.create_model(TIMM, pretrained=False, num_classes=2); m.load_state_dict(torch.load(f"{R}/models/{NAME}.pt", map_location="cpu"))
m.reset_classifier(0); m = m.eval().to(dev).to(memory_format=torch.channels_last); t0 = time.time(); n = 0
for cond in ["orig", "rs", "jpg", "c"]:
    od = f"{R}/feats/face/{cond}/{NAME}"; os.makedirs(od, exist_ok=True)
    for s in sorted(glob.glob(f"{R}/data/proc/face/{cond}/*.tar")):
        o = f"{od}/{os.path.basename(s)}.npz"
        if os.path.exists(o): continue
        with tarfile.open(s) as t: its = [(mm.name.removesuffix(".jpg"), t.extractfile(mm).read()) for mm in t if mm.isfile()]
        fs = []
        with torch.inference_mode(), torch.autocast("cuda", dtype=torch.bfloat16):
            for x in torch.utils.data.DataLoader(Eval(its), batch_size=512, num_workers=int(os.environ.get("NW", 14))):
                fs.append(m(x.to(dev).to(memory_format=torch.channels_last)).float().cpu().numpy().astype(np.float16))
        np.savez(o, keys=np.array([k + ".jpg" for k, _ in its]), emb=np.concatenate(fs)); n += len(its)
        print(cond, os.path.basename(s), len(its), f"({time.time()-t0:.0f}s)", flush=True)
print("FEAT_FT_NEW_OK", NAME, n)
