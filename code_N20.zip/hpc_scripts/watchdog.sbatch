#!/bin/bash
#SBATCH -J watchdog
#SBATCH -p l40s
#SBATCH -c 1
#SBATCH --mem=2G
#SBATCH -t 2-23:30:00
#SBATCH -o /virtiofs/work/bambang/cascade/logs/%x_%j.out
# Supervisor that keeps the pipeline moving with no interactive shell:
#  - restarts the Google Drive download whenever it is not queued/running, until a clean pass;
#  - writes logs/status_now.txt every 10 minutes;
#  - resubmits itself before the 3-day limit while work remains.
R=/virtiofs/work/bambang/cascade; cd $R
END=$(( $(date +%s) + 70*3600 ))
DONE=$R/data/raw/.gdrive_complete
while [ $(date +%s) -lt $END ]; do
  if [ ! -f $DONE ] && ! squeue -h -u $USER -n dl_gdrive | grep -q .; then
    LAST=$(ls -t logs/dl_gdrive_*.out 2>/dev/null | head -1)
    if [ -n "$LAST" ] && grep -q GDRIVE_DONE "$LAST" && ! grep -qiE "failed|error" "$LAST"; then
      date '+%F %T' > $DONE; echo "$(date '+%F %T') gdrive complete ($LAST)"
    else
      J=$(sbatch --parsable scripts/05_dl_gdrive.sbatch); echo "$(date '+%F %T') restarted dl_gdrive as $J (last log: $LAST)"
      echo "WATCHDOG $(date '+%d%b %H:%M') gdrive=$J" >> logs/launch.txt
    fi
  fi
  { echo "== $(date '+%F %T')"; bash scripts/status.sh 2>&1
    echo "== files"; for d in data/raw/df40/train data/raw/df40/test data/raw/df40/json data/raw/diff/fake data/raw/df40_real; do
      printf "%s: %s files, %s\n" $d "$(find $d -type f 2>/dev/null | wc -l)" "$(du -sh $d 2>/dev/null | cut -f1)"; done
    [ -f $DONE ] && echo "GDRIVE COMPLETE $(cat $DONE)"; } > logs/status_now.txt.tmp && mv logs/status_now.txt.tmp logs/status_now.txt
  sleep 600
done
[ -f $DONE ] || { J=$(sbatch --parsable scripts/watchdog.sbatch); echo "$(date '+%F %T') watchdog resubmitted as $J"; }
