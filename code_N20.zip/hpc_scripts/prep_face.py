"""J2-face: DF40 + DiFF + real faces -> harmonised JPEG shards in 4 compression conditions (same format as cf_eval).

Family-level generator shift (fixed before any result was seen):
  source (tiers are trained here)  = DF40 *train* split, families FS (face-swap) + GAN entire-face synthesis
                                     (stylegan2/3/xl, vqgan, whichfaceisreal) + half of the FF++/Celeb-DF real videos
  target (calibrate / certify / test) = DF40 *test* split, families FR (reenactment), FE (face edit) and
                                     diffusion entire-face synthesis (sd2.1, ddim, pixart, dit, sit, rddm, midjourney)
                                     + all DiFF (T2I, I2I, FS, FE; train/val/test merged) + DF40 real folders
                                     + the other half of the FF++/Celeb-DF real videos.
Reals are split by video/identity folder (hash of parent directory), so no video appears on both sides.
At most CAP images per (dataset, generator) fake set are kept (frames of a video are near-duplicates).
"""
import io, os, sys, csv, tarfile, hashlib, time, zlib
from multiprocessing import Pool
import numpy as np, pandas as pd
from PIL import Image
R = "/virtiofs/work/bambang/cascade"; E = f"{R}/data/ext"; OUT = f"{R}/data/proc/face"
CONDS = ("orig", "rs", "jpg", "c"); CAP = int(os.environ.get("CAP", 6000)); SHARD = 4000; SEED = 20261113
GAN_EFS = {"stylegan2", "stylegan3", "styleganxl", "vqgan", "whichfaceisreal"}

def crop256(im):
    im = im.convert("RGB"); w, h = im.size; s = min(w, h); l, t = (w - s) // 2, (h - s) // 2
    return im.crop((l, t, l + s, t + s)).resize((256, 256), Image.BICUBIC)
def jpg(im, q): b = io.BytesIO(); im.save(b, "JPEG", quality=q); return b.getvalue()
def variant(im, c):
    if c == "orig": return jpg(im, 95)
    if c == "rs": return jpg(im.resize((192, 192), Image.BICUBIC), 95)
    if c == "jpg": return jpg(Image.open(io.BytesIO(jpg(im, 75))), 60)
    return jpg(Image.open(io.BytesIO(jpg(im.resize((192, 192), Image.BICUBIC), 75))), 60)

def assign(m):
    g = m["generator"].str.lower(); fam = m["family"]
    vid = m["path"].map(lambda p: zlib.crc32(os.path.dirname(p).encode()) % 2)
    role = np.full(len(m), "", object)
    df40 = m["dataset"] == "df40"
    role[(df40 & (m["split"] == "train") & ((fam == "FS") | g.isin(GAN_EFS))).values] = "source"
    role[(df40 & (m["split"] == "test") & (fam.isin(["FR", "FE"]) | ((fam == "EFS") & ~g.isin(GAN_EFS)))).values] = "target"
    role[(m["dataset"] == "diff").values] = "target"
    role[(df40 & (m["label"] == 0)).values] = "target"
    rr = (m["dataset"] == "real").values; role[rr] = np.where(vid.values[rr] == 0, "source", "target")
    m = m.assign(role=role); m = m[m["role"] != ""]
    fake = m[m["label"] == 1].sample(frac=1, random_state=SEED).groupby(["role", "dataset", "generator"]).head(CAP)
    return pd.concat([fake, m[m["label"] == 0]]).sample(frac=1, random_state=SEED).reset_index(drop=True)

def work(args):
    k, rows = args; name = f"face_{k:04d}"; done = f"{OUT}/manifest/{name}.csv"
    if os.path.exists(done): return name, "skip"
    tars = {c: tarfile.open(f"{OUT}/{c}/{name}.tar.tmp", "w") for c in CONDS}; out = []
    for i, r in enumerate(rows):
        try:
            raw = open(f"{E}/{r['path']}", "rb").read(); im = crop256(Image.open(io.BytesIO(raw)))
        except Exception: continue
        key = f"{name}_{i:05d}"
        for c in CONDS:
            data = variant(im, c); ti = tarfile.TarInfo(f"{key}.jpg"); ti.size = len(data); tars[c].addfile(ti, io.BytesIO(data))
        out.append({"key": key, "sha256_raw": hashlib.sha256(raw).hexdigest(), **r})
    for c, t in tars.items(): t.close(); os.replace(f"{OUT}/{c}/{name}.tar.tmp", f"{OUT}/{c}/{name}.tar")
    with open(done + ".tmp", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(out[0])); w.writeheader(); w.writerows(out)
    os.replace(done + ".tmp", done); return name, len(out)

if __name__ == "__main__":
    for d in (*CONDS, "manifest"): os.makedirs(f"{OUT}/{d}", exist_ok=True)
    m = assign(pd.read_csv(f"{OUT}/manifest.csv.gz"))
    m.to_csv(f"{OUT}/selection.csv.gz", index=False)
    print(m.groupby(["role", "dataset", "family", "label"]).size().to_string(), flush=True)
    recs = m.to_dict("records"); jobs = [(k, recs[i:i + SHARD]) for k, i in enumerate(range(0, len(recs), SHARD))]
    t0 = time.time(); tot = 0
    with Pool(int(os.environ.get("SLURM_CPUS_PER_TASK", 32))) as p:
        for j, (name, n) in enumerate(p.imap_unordered(work, jobs), 1):
            tot += n if isinstance(n, int) else 0; print(f"[{j}/{len(jobs)}] {name}: {n} ({time.time()-t0:.0f}s)", flush=True)
    print("PREP_FACE_OK", tot)
