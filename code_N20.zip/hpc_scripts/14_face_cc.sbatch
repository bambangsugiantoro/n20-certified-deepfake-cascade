#!/bin/bash
#SBATCH -J face_cc
#SBATCH -p l40s
#SBATCH -c 120
#SBATCH --mem=400G
#SBATCH -t 1-00:00:00
#SBATCH -o /virtiofs/work/bambang/cascade/logs/%x_%j.out
# Face run 3 (CPU): CLASS-CONDITIONAL risk (false-real rate on fakes <= 10 %, false-fake rate on reals <= 5 %,
# each certified at alpha/2). Fixes the vacuous marginal risk at prevalence 1 % found in face_main2.
R=/virtiofs/work/bambang/cascade; cd $R
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 SLURM_CPUS_PER_TASK=118 DS=face
export PILOT_NAME=face_cc RISK=cc DELTA_CC=0.05,0.10 CONDS=orig,rs,jpg,c PREVS=0.5,0.1,0.01 BUDGETS=800,3200,6400,12800 WEIGHTS=0.1,0.1,0.8
export TIERS_JSON='{"1": ["mnv3_l_face"], "2": ["resnet50_face"], "3": ["clip_l14", "dinov2_l14"]}'
apptainer exec $R/env/pytorch.sif $R/env/venv/bin/python $R/scripts/ctc_pilot2.py
