"""J2: parquet (image bytes + metadata) -> harmonised JPEG in 4 compression conditions, as tar shards + manifest.
One worker per parquet file; uses all CPUs given by Slurm."""
import io, os, sys, glob, csv, json, tarfile, hashlib, time
from multiprocessing import Pool
import pyarrow.parquet as pq
from PIL import Image
Image.MAX_IMAGE_PIXELS = None
RAW, OUT = sys.argv[1], sys.argv[2]
CONDS = ("orig", "rs", "jpg", "c")

def crop256(im):
    im = im.convert("RGB"); w, h = im.size; s = min(w, h)
    l, t = (w - s) // 2, (h - s) // 2
    return im.crop((l, t, l + s, t + s)).resize((256, 256), Image.BICUBIC)

def jpg(im, q):
    b = io.BytesIO(); im.save(b, "JPEG", quality=q); return b.getvalue()

def variant(im, c):
    if c == "orig": return jpg(im, 95)
    if c == "rs": return jpg(im.resize((192, 192), Image.BICUBIC), 95)
    if c == "jpg": return jpg(Image.open(io.BytesIO(jpg(im, 75))), 60)
    return jpg(Image.open(io.BytesIO(jpg(im.resize((192, 192), Image.BICUBIC), 75))), 60)

def image_bytes(v):
    if isinstance(v, dict): return v.get("bytes")
    return v if isinstance(v, (bytes, bytearray)) else None

def work(path):
    name = os.path.relpath(path, RAW).replace("/", "__").removesuffix(".parquet")
    done = f"{OUT}/manifest/{name}.csv"
    if os.path.exists(done): return name, "skip"
    pf = pq.ParquetFile(path)
    tars = {c: tarfile.open(f"{OUT}/{c}/{name}.tar.tmp", "w") for c in CONDS}
    rows, n = [], 0
    for rg in range(pf.num_row_groups):
        tbl = pf.read_row_group(rg).to_pylist()
        for i, rec in enumerate(tbl):
            img_col = next((k for k, v in rec.items() if image_bytes(v)), None)
            if img_col is None: continue
            raw = image_bytes(rec[img_col])
            try: im = crop256(Image.open(io.BytesIO(raw)))
            except Exception: continue
            key = f"{name}_{rg:04d}_{i:06d}"
            for c in CONDS:
                data = variant(im, c); ti = tarfile.TarInfo(f"{key}.jpg"); ti.size = len(data)
                tars[c].addfile(ti, io.BytesIO(data))
            meta = {k: v for k, v in rec.items() if k != img_col and not isinstance(v, (bytes, bytearray, dict))}
            rows.append({"key": key, "sha256_raw": hashlib.sha256(raw).hexdigest(), "src_file": name, **meta}); n += 1
    for c, t in tars.items():
        t.close(); os.replace(f"{OUT}/{c}/{name}.tar.tmp", f"{OUT}/{c}/{name}.tar")
    if rows:
        with open(done + ".tmp", "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=sorted({k for r in rows for k in r})); w.writeheader(); w.writerows(rows)
        os.replace(done + ".tmp", done)
    return name, n

if __name__ == "__main__":
    for d in (*CONDS, "manifest"): os.makedirs(f"{OUT}/{d}", exist_ok=True)
    files = sorted(glob.glob(f"{RAW}/**/*.parquet", recursive=True))
    ncpu = int(os.environ.get("SLURM_CPUS_PER_TASK", os.cpu_count()))
    t0 = time.time(); total = 0
    with Pool(ncpu) as p:
        for k, (name, n) in enumerate(p.imap_unordered(work, files), 1):
            total += n if isinstance(n, int) else 0
            print(f"[{k}/{len(files)}] {name}: {n}  ({time.time()-t0:.0f}s)", flush=True)
    print("PREP_OK images", total)
