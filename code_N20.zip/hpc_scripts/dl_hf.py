"""Resumable download of a Hugging Face dataset repo with retries (hf_transfer when available)."""
import os, sys, time
os.environ.setdefault("HF_HUB_ENABLE_HF_TRANSFER", "1")
from huggingface_hub import snapshot_download
repo, out = sys.argv[1], sys.argv[2]
pat = sys.argv[3].split(",") if len(sys.argv) > 3 else None
for attempt in range(30):
    try:
        p = snapshot_download(repo, repo_type="dataset", local_dir=out, allow_patterns=pat,
                              max_workers=int(os.environ.get("NW", "16")))
        print("DOWNLOAD_OK", p, flush=True); break
    except Exception as e:
        print(f"retry {attempt}: {e}", flush=True); time.sleep(60)
else:
    sys.exit("DOWNLOAD_FAILED")
