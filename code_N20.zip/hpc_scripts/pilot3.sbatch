#!/bin/bash
#SBATCH -J pilot3_ft
#SBATCH -p l40s
#SBATCH --gres=gpu:2
#SBATCH -c 64
#SBATCH --mem=240G
#SBATCH -t 12:00:00
#SBATCH -o /virtiofs/work/bambang/cascade/logs/%x_%j.out
# Pilot 3: fine-tune cheap tiers on source (MobileNetV3-L on GPU0, ResNet-50 on GPU1, in parallel),
# then rerun Adapt+CTC with the fine-tuned tiers (CPU).
R=/virtiofs/work/bambang/cascade; cd $R
ulimit -n 65536 2>/dev/null || true
export HF_HOME=$R/env/hf OMP_NUM_THREADS=2 NW=28
RUN="apptainer exec --nv $R/env/pytorch.sif $R/env/venv/bin/python"
CUDA_VISIBLE_DEVICES=0 $RUN $R/scripts/finetune_tier.py mobilenetv3_large_100.ra_in1k mnv3_l_ft > $R/logs/ft_mnv3.log 2>&1 &
CUDA_VISIBLE_DEVICES=1 $RUN $R/scripts/finetune_tier.py resnet50.a1_in1k resnet50_ft > $R/logs/ft_resnet50.log 2>&1 &
wait
tail -3 $R/logs/ft_mnv3.log $R/logs/ft_resnet50.log
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 SLURM_CPUS_PER_TASK=62 PILOT_NAME=pilot3
export TIERS_JSON='{"1": ["mnv3_l_ft"], "2": ["resnet50_ft"], "3": ["clip_l14", "dinov2_l14"]}'
$RUN $R/scripts/ctc_pilot2.py
