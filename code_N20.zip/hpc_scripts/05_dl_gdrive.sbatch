#!/bin/bash
#SBATCH -J dl_gdrive
#SBATCH -p l40s
#SBATCH -c 8
#SBATCH --mem=16G
#SBATCH -t 3-00:00:00
#SBATCH -o /virtiofs/work/bambang/cascade/logs/%x_%j.out
# J1b: DF40 (fake test/train + FF++/CDF real frames) and DiFF fake images from public Google Drive links.
# Links recorded from github.com/YZY-stack/DF40 and github.com/xacheng1996/diff (12 Nov 2026).
R=/virtiofs/work/bambang/cascade; S=$R/scripts/dl_gdrive.sh; D=$R/data/raw
apptainer exec $R/env/pytorch.sif $R/env/venv/bin/pip install -q gdown
bash $S file   https://drive.google.com/file/d/1dHJdS0NZ6wpewbGA5B0PdIBS9gz28pdb/view   $D/df40_real/ffpp
bash $S file   https://drive.google.com/file/d/1FGZ3aYsF-Yru50rPLoT5ef8-2Nkt4uBw/view   $D/df40_real/cdf
bash $S folder https://drive.google.com/drive/folders/19VhAL4aDJOKvhl9stEq_ymFeHiXo6_j-  $D/df40/json
bash $S folder https://drive.google.com/drive/folders/1U8meBbqVvmUkc5GD0jxct6xe6Gwk9wKD  $D/df40/train
bash $S folder https://drive.google.com/drive/folders/1980LCMAutfWvV6zvdxhoeIa67TmzKLQ_  $D/df40/test
bash $S folder https://drive.google.com/drive/folders/13uTBF7-YkqtpGNjc9QvqzaBfBJ5fe7-w  $D/diff/fake
echo GDRIVE_DONE
