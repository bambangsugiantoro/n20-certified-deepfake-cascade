"""Pilot v2: certified cascades WITH target adaptation (Adapt+CTC) on Community Forensics Eval.

Per draw, the n target labels are split in two disjoint halves:
  - half A adapts every tier (logistic probe refit on PCA features, source subsample + target labels);
  - half C certifies the adapted cascades (label-free path built on U_E with adapted confidences,
    then fixed-sequence Clopper-Pearson). Validity holds conditionally on half A.
Tier 3 = CLIP ViT-L/14 + DINOv2 ViT-L/14 features concatenated.
"""
import os, glob, math, time
import numpy as np, pandas as pd
from multiprocessing import get_context
from scipy.stats import beta
from sklearn.linear_model import LogisticRegression
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

R = os.environ.get("R", "/virtiofs/work/bambang/cascade")
import json
OUT = f"{R}/results/" + os.environ.get("PILOT_NAME", "pilot2"); os.makedirs(OUT, exist_ok=True)
TIERS = {int(k): v for k, v in json.loads(os.environ.get("TIERS_JSON", '{"1": ["mnv3_l"], "2": ["resnet50"], "3": ["clip_l14", "dinov2_l14"]}')).items()}
COST = {1: 0.22, 2: 4.1, 3: 81.0 + 77.8}       # GFLOPs proxy (tier 3 runs two ViT-L/14)
CONFIGS = {"A": [1, 2, 3], "B": [1, 3], "C": [3]}
WEIGHTS = {k: float(v) for k, v in zip(CONFIGS, os.environ.get("WEIGHTS", "0.1,0.1,0.8").split(","))}   # weighted Bonferroni split for SETW
ALPHA, DELTA, GRID, PCADIM, NSRC = 0.05, 0.05, 20, 256, 4000
RISK = os.environ.get("RISK", "marginal")        # marginal: P(wrong | released) <= DELTA
# cc (class-conditional): P(released & wrong | real) <= D_REAL and P(released & wrong | fake) <= D_FAKE, each certified at a/2
D_REAL, D_FAKE = [float(x) for x in os.environ.get("DELTA_CC", "0.05,0.10").split(",")]
STRAT = os.environ.get("STRAT", "0") == "1"      # stratified labelling: half reals, half fakes (valid for class-conditional risk)
GROUP = os.environ.get("GROUP", "0") == "1"      # group-conditional: miss rate <= D_FAKE for EVERY target fake family
DS = os.environ.get("DS", "cf_eval")
BUDGETS = [int(x) for x in os.environ.get("BUDGETS", "400,800,1600,3200").split(",")]
PREVS = [float(x) for x in os.environ.get("PREVS", "0.5,0.1").split(",")]
CONDS = os.environ.get("CONDS", "orig,c").split(",")
NSPLIT, NDRAW = 10, 20
SEED = 20261113
G = {}                                           # filled before forking workers (copy-on-write)
FAMS = []                                        # target fake families (GROUP mode)

def load_manifest():
    fs = sorted(glob.glob(f"{R}/data/proc/{DS}/manifest/*.csv"))
    m = pd.concat([pd.read_csv(f) for f in fs], ignore_index=True)
    if "role" not in m:                                  # cf_eval: source = open generators, target = commercial
        m["role"] = np.where(m["architecture"] == "Commercial", "target", "source")
    m["label"] = m["label"].astype(int); return m.set_index("key")

def load_feats(cond, model):
    keys, embs = [], []
    for f in sorted(glob.glob(f"{R}/feats/{DS}/{cond}/{model}/*.npz")):
        z = np.load(f); keys += [k.removesuffix(".jpg") for k in z["keys"]]; embs.append(z["emb"].astype(np.float32))
    k = pd.Index(keys); o = np.argsort(k.values); return k[o], np.concatenate(embs)[o]

def cp_upper(k, m, a):
    return 1.0 if m == 0 or k >= m else beta.ppf(1 - a, k + 1, m - k)

def cascade(conf, err, tiers, th):
    alive = np.ones(len(conf[tiers[0]]), bool); rel = np.zeros_like(alive); e = np.zeros_like(alive); c = np.zeros(len(alive))
    for i, t in enumerate(tiers):
        c += alive * COST[t]; hit = alive & (conf[t] >= th[i]); rel |= hit; e |= hit & err[t]; alive &= ~hit
    return rel, e, c

def build_path(confE, tiers):
    """Label-free monotone path on U_E; error estimate = 1 - confidence of the releasing tier."""
    q = {t: np.r_[np.inf, np.quantile(confE[t], 1 - np.arange(1, GRID + 1) / GRID)] for t in tiers}
    def stats(js):
        th = [q[t][js[i]] for i, t in enumerate(tiers)]
        alive = np.ones(len(confE[tiers[0]]), bool); r = np.zeros_like(alive); c = np.zeros(len(alive)); e = 0.0
        for i, t in enumerate(tiers):
            c += alive * COST[t]; hit = alive & (confE[t] >= th[i]); e += (1 - confE[t][hit]).sum(); r |= hit; alive &= ~hit
        n = len(alive); return r.mean(), c.mean() / COST[tiers[-1]], e / n
    j = [0] * len(tiers); path = [[np.inf] * len(tiers)]; r0, c0, e0 = stats(j)
    while any(x < GRID for x in j):
        best = None
        for i in range(len(tiers)):
            if j[i] >= GRID: continue
            cand = j.copy(); cand[i] += 1; r, c, e = stats(cand)
            sc = (r - r0) - 0.5 * (c - c0) - (e - e0) / DELTA
            if best is None or sc > best[0]: best = (sc, cand, r, c, e)
        _, j, r0, c0, e0 = best; path.append([q[t][j[i]] for i, t in enumerate(tiers)])
    return np.array(path)

def risk_of(rel, e, yv, fv=None):
    """Realised risk on held-out data, in the same sense that is certified."""
    if RISK == "cc" and GROUP and fv is not None:
        r = [e[yv == 0].mean() / D_REAL] + [e[(yv == 1) & (fv == f)].mean() / D_FAKE for f in np.unique(fv[yv == 1])]
        return max(r) * DELTA
    if RISK == "cc":
        return max(e[yv == 0].mean() / D_REAL, e[yv == 1].mean() / D_FAKE) * DELTA if len(yv) else np.nan
    return e[rel].mean() if rel.any() else np.nan

def certify(confL, errL, tiers, path, a, nC, expE, yL=None, fL=None, nfam=1):
    mmin = math.ceil(math.log(a) / math.log(1 - DELTA)); hat = -1
    for lam, th in enumerate(path):
        if RISK != "cc" and nC * expE[lam] < mmin: continue
        rel, e, _ = cascade(confL, errL, tiers, th)
        if RISK == "cc" and GROUP:
            ok = cp_upper((e & (yL == 0)).sum(), (yL == 0).sum(), a / 2) <= D_REAL and all(
                cp_upper((e & (yL == 1) & (fL == f)).sum(), ((yL == 1) & (fL == f)).sum(), a / (2 * nfam)) <= D_FAKE
                for f in FAMS)
        elif RISK == "cc":
            ok = cp_upper((e & (yL == 0)).sum(), (yL == 0).sum(), a / 2) <= D_REAL and \
                 cp_upper((e & (yL == 1)).sum(), (yL == 1).sum(), a / 2) <= D_FAKE
        else:
            ok = cp_upper(e.sum(), rel.sum(), a) <= DELTA
        if ok: hat = lam
        else: break
    return hat

def fit_tier(Xs, ys, Xt, yt, w_t):
    X = np.vstack([Xs, Xt]); y = np.r_[ys, yt]
    w = np.r_[np.ones(len(ys)), np.full(len(yt), w_t)]
    sc = StandardScaler().fit(X); clf = LogisticRegression(C=0.1, max_iter=2000).fit(sc.transform(X), y, sample_weight=w)
    return sc, clf

def run(args):
    cond, prev, s = args; D = G[cond]; y = D["y"]; fam = D.get("fam")
    rng = np.random.default_rng(SEED + 100 * s + int(prev * 1000) + (0 if cond == "orig" else 7))
    real, fake = np.where(y == 0)[0], np.where(y == 1)[0]
    if prev >= 0.5: nr = nf = min(len(real), len(fake))
    else: nr, nf = len(real), min(len(fake), int(round(len(real) * prev / (1 - prev))))
    pool = np.r_[rng.choice(real, nr, replace=False), rng.choice(fake, nf, replace=False)]; rng.shuffle(pool)
    E, L = pool[: len(pool) // 2], pool[len(pool) // 2:]
    src = rng.choice(len(D["ys"]), min(NSRC, len(D["ys"])), replace=False)
    rows = []
    for n in BUDGETS:
        for d in range(NDRAW):
            if STRAT:                                # half reals, half fakes (capped by availability)
                Lr, Lf = L[y[L] == 0], L[y[L] == 1]; nf_ = min(n // 2, len(Lf))
                lab = np.r_[rng.choice(Lr, min(n - nf_, len(Lr)), replace=False), rng.choice(Lf, nf_, replace=False)]; rng.shuffle(lab)
            else:
                lab = rng.choice(L, min(n, len(L)), replace=False)
            A_, C_ = lab[: len(lab) // 2], lab[len(lab) // 2:]
            conf, err, setbad, setrel, wbad, wrel = {}, {}, False, 0.0, False, 0.0
            for t in TIERS:
                Xs, Xt = D["Xs"][t][src], D["Xt"][t]
                sc, clf = fit_tier(Xs, D["ys"][src], Xt[A_], y[A_], w_t=NSRC / max(len(A_), 1))
                p = clf.predict_proba(sc.transform(Xt))[:, 1]
                conf[t] = np.maximum(p, 1 - p); err[t] = (p >= 0.5).astype(int) != y
            for g, tiers in CONFIGS.items():
                cE = {t: conf[t][E] for t in tiers}; eE = {t: err[t][E] for t in tiers}
                path = build_path(cE, tiers)
                expE = np.array([cascade(cE, eE, tiers, th)[0].mean() for th in path])
                cL = {t: conf[t][C_] for t in tiers}; eL = {t: err[t][C_] for t in tiers}
                for mode, a in (("set", ALPHA / len(CONFIGS)), ("setw", ALPHA * WEIGHTS[g]), ("alone", ALPHA)):
                    hat = certify(cL, eL, tiers, path, a, len(C_), expE, y[C_], fam[C_] if fam is not None else None, len(FAMS))
                    if hat < 0:
                        rr, risk, cst = 0.0, np.nan, cascade(cE, eE, tiers, path[0])[2].mean()
                    else:
                        rel, e, c = cascade(cE, eE, tiers, path[hat]); rr = rel.mean(); risk = risk_of(rel, e, y[E], fam[E] if fam is not None else None); cst = c.mean()
                    if mode == "set":
                        setbad |= not (np.isnan(risk) or risk <= DELTA); setrel = max(setrel, rr)
                    if mode == "setw":
                        wbad |= not (np.isnan(risk) or risk <= DELTA); wrel = max(wrel, rr)
                    rows.append(dict(cond=cond, prev=prev, split=s, n=n, draw=d, config=g, mode=mode, release=rr, risk=risk,
                                     cost_gflops=cst, valid=bool(np.isnan(risk) or risk <= DELTA)))
            rows.append(dict(cond=cond, prev=prev, split=s, n=n, draw=d, config="SET", mode="set", release=setrel,
                             risk=np.nan, cost_gflops=np.nan, valid=not setbad))
            rows.append(dict(cond=cond, prev=prev, split=s, n=n, draw=d, config="SETW", mode="setw", release=wrel,
                             risk=np.nan, cost_gflops=np.nan, valid=not wbad))
            # uncertified heuristic on adapted detectors
            rel, e, c = cascade({t: conf[t][E] for t in CONFIGS["A"]}, {t: err[t][E] for t in CONFIGS["A"]}, CONFIGS["A"], [0.9, 0.9, 0.9])
            rows.append(dict(cond=cond, prev=prev, split=s, n=n, draw=d, config="A_heuristic0.9", mode="uncertified",
                             release=rel.mean(), risk=risk_of(rel, e, y[E]), cost_gflops=c.mean(),
                             valid=bool(np.isnan(risk_of(rel, e, y[E])) or risk_of(rel, e, y[E]) <= DELTA)))
            for t in TIERS: rows.append(dict(cond=cond, prev=prev, split=s, n=n, draw=d, config=f"tier{t}_acc", mode="adapted",
                                             release=np.nan, risk=err[t][E].mean(), cost_gflops=COST[t], valid=True))
    return rows

if __name__ == "__main__":
    t0 = time.time(); man = load_manifest()
    for cond in CONDS:
        Xs, Xt, ys, yt = {}, {}, None, None
        for t, models in TIERS.items():
            parts_s, parts_t = [], []
            for mname in models:
                ko, Xo = load_feats("orig", mname); kc, Xc = (ko, Xo) if cond == "orig" else load_feats(cond, mname)
                mo, mc = man.reindex(ko), man.reindex(kc)
                srcm = (mo["role"] == "source").values; tgtm = (mc["role"] == "target").values
                if os.environ.get("TGT_DATASET"): tgtm &= (mc["dataset"] == os.environ["TGT_DATASET"]).values   # e.g. DiFF-only target
                pca = PCA(min(PCADIM, Xo.shape[1] - 1), random_state=SEED).fit(Xo[srcm][::2])
                parts_s.append(pca.transform(Xo[srcm])); parts_t.append(pca.transform(Xc[tgtm]))
                ys_, yt_ = mo["label"].values[srcm], mc["label"].values[tgtm]
                if ys is None: ys, yt = ys_, yt_; ft = (mc["dataset"].astype(str) + ":" + mc["family"].astype(str)).values[tgtm]
                assert (ys == ys_).all() and (yt == yt_).all()
            Xs[t], Xt[t] = np.hstack(parts_s).astype(np.float32), np.hstack(parts_t).astype(np.float32)
            print(cond, "tier", t, Xs[t].shape, Xt[t].shape, flush=True)
        G[cond] = dict(Xs=Xs, Xt=Xt, ys=ys, y=yt, fam=ft)
        FAMS[:] = sorted(set(ft[yt == 1]))
    jobs = [(c, p, s) for c in CONDS for p in PREVS for s in range(NSPLIT)]
    ncpu = int(os.environ.get("SLURM_CPUS_PER_TASK", 8))
    os.environ["OMP_NUM_THREADS"] = "1"
    with get_context("fork").Pool(ncpu) as pool:
        res = [r for rows in pool.imap_unordered(run, jobs) for r in rows]
    df = pd.DataFrame(res); df.to_csv(f"{OUT}/draws.csv.gz", index=False)
    summ = df.groupby(["cond", "prev", "n", "config", "mode"]).agg(
        validity=("valid", "mean"), release=("release", "mean"), risk=("risk", "mean"),
        cost_gflops=("cost_gflops", "mean"), draws=("valid", "size")).reset_index()
    summ.to_csv(f"{OUT}/summary.csv", index=False); print(summ.to_string(), flush=True)
    print(f"PILOT2_OK {time.time()-t0:.0f}s")
