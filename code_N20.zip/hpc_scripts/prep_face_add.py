"""Add DiFF real images (granted 13 Nov 2026) to the face data as TARGET reals, in NEW shards face_dr_XXXX
(4 compression conditions, same harmonisation as prep_face.py); existing shards are untouched."""
import os, sys, csv, tarfile, hashlib, io, time, re
from multiprocessing import Pool
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from prep_face import crop256, variant, CONDS, OUT, E, SHARD
from PIL import Image
IMG = re.compile(r"\.(png|jpe?g|webp)$", re.I)

def work(args):
    k, paths = args; name = f"face_dr_{k:04d}"; done = f"{OUT}/manifest/{name}.csv"
    if os.path.exists(done): return name, "skip"
    tars = {c: tarfile.open(f"{OUT}/{c}/{name}.tar.tmp", "w") for c in CONDS}; out = []
    for i, p in enumerate(paths):
        try: raw = open(f"{E}/{p}", "rb").read(); im = crop256(Image.open(io.BytesIO(raw)))
        except Exception: continue
        key = f"{name}_{i:05d}"
        for c in CONDS:
            d = variant(im, c); ti = tarfile.TarInfo(f"{key}.jpg"); ti.size = len(d); tars[c].addfile(ti, io.BytesIO(d))
        out.append(dict(key=key, sha256_raw=hashlib.sha256(raw).hexdigest(), path=p, dataset="diff", split="all",
                        generator="DiFF_real", family="REAL", label=0, src="", role="target"))
    for c, t in tars.items(): t.close(); os.replace(f"{OUT}/{c}/{name}.tar.tmp", f"{OUT}/{c}/{name}.tar")
    with open(done + ".tmp", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(out[0])); w.writeheader(); w.writerows(out)
    os.replace(done + ".tmp", done); return name, len(out)

if __name__ == "__main__":
    paths = sorted(os.path.relpath(os.path.join(d, f), E) for d, _, fs in os.walk(f"{E}/diff/real")
                   if "__MACOSX" not in d for f in fs if IMG.search(f) and not f.startswith("._"))
    print("DiFF real images:", len(paths), flush=True)
    jobs = [(k, paths[i:i + SHARD]) for k, i in enumerate(range(0, len(paths), SHARD))]
    t0 = time.time(); tot = 0
    with Pool(int(os.environ.get("SLURM_CPUS_PER_TASK", 32))) as p:
        for name, n in p.imap_unordered(work, jobs):
            tot += n if isinstance(n, int) else 0; print(name, n, f"({time.time()-t0:.0f}s)", flush=True)
    print("PREP_ADD_OK", tot)
