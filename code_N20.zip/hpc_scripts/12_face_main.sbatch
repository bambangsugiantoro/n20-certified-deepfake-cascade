#!/bin/bash
#SBATCH -J face_main
#SBATCH -p l40s
#SBATCH --gres=gpu:2
#SBATCH -c 64
#SBATCH --mem=240G
#SBATCH -t 2-00:00:00
#SBATCH -o /virtiofs/work/bambang/cascade/logs/%x_%j.out
# Fine-tune tier 1 (MobileNetV3-L, GPU0) and tier 2 (ResNet-50, GPU1) on the face SOURCE families in parallel,
# then the main Adapt+CTC experiment on face data: 4 compression conditions x prevalence 50/10/1 %.
R=/virtiofs/work/bambang/cascade; cd $R
ulimit -n 65536 2>/dev/null || true
export HF_HOME=$R/env/hf OMP_NUM_THREADS=2 NW=28 DS=face
RUN="apptainer exec --nv $R/env/pytorch.sif $R/env/venv/bin/python"
CUDA_VISIBLE_DEVICES=0 $RUN $R/scripts/finetune_tier.py mobilenetv3_large_100.ra_in1k mnv3_l_face > $R/logs/ft_mnv3_face.log 2>&1 &
CUDA_VISIBLE_DEVICES=1 $RUN $R/scripts/finetune_tier.py resnet50.a1_in1k resnet50_face > $R/logs/ft_resnet50_face.log 2>&1 &
wait
tail -3 $R/logs/ft_mnv3_face.log $R/logs/ft_resnet50_face.log
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 SLURM_CPUS_PER_TASK=62
export PILOT_NAME=face_main CONDS=orig,rs,jpg,c PREVS=0.5,0.1,0.01
export TIERS_JSON='{"1": ["mnv3_l_face"], "2": ["resnet50_face"], "3": ["clip_l14", "dinov2_l14"]}'
$RUN $R/scripts/ctc_pilot2.py
