#!/bin/bash
# Quick status: queue, recent jobs, data sizes, last log lines.
R=/virtiofs/work/bambang/cascade
squeue -u $USER -o '%.10i %.12j %.2t %.10M %.6D %C %b %R'
sacct -u $USER -S today -o JobID%18,JobName%12,State,Elapsed,AllocCPUS,ReqTRES%40,MaxRSS -X
du -sh $R/data/raw/* $R/data/proc/* $R/feats/* 2>/dev/null
for f in $(ls -t $R/logs/*.out 2>/dev/null | head -4); do echo "== $f"; tail -3 $f; done
