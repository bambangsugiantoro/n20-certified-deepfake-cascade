#!/bin/bash
#SBATCH -J face_family
#SBATCH -p l40s
#SBATCH -c 64
#SBATCH --mem=300G
#SBATCH -t 12:00:00
#SBATCH -o /virtiofs/work/bambang/cascade/logs/%x_%j.out
# Per-family breakdown (class-conditional risk), pi=0.5, n=12800, 10 splits x 5 draws, 4 conditions
R=/virtiofs/work/bambang/cascade; cd $R
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 SLURM_CPUS_PER_TASK=40 DS=face RISK=cc DELTA_CC=0.05,0.10
export CONDS=orig,rs,jpg,c PILOT_NAME=face_family
export TIERS_JSON='{"1": ["mnv3_l_face"], "2": ["resnet50_face"], "3": ["clip_l14", "dinov2_l14"]}'
apptainer exec $R/env/pytorch.sif $R/env/venv/bin/python $R/scripts/per_family.py
