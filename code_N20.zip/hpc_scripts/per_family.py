"""Per-family breakdown on face data (class-conditional risk, same pipeline as ctc_pilot2 with RISK=cc).
For each condition, prevalence 0.5 and n=12800, NSPLIT x NDRAW draws: certify configurations A and C at alpha,
then report per target family (dataset:family; reals = REAL) the adapted tier error, the release rate and the
error rate among released images, plus the miss rate (fake released as real) per family.
Output: results/face_family/per_family.csv"""
import os, sys, time
os.environ.setdefault("RISK", "cc"); os.environ.setdefault("DS", "face")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, pandas as pd
from multiprocessing import get_context
import ctc_pilot2 as c

N, PREV, NDRAW = int(os.environ.get("NFAM", 12800)), 0.5, int(os.environ.get("NDRAW_FAM", 5))
OUT = f"{c.R}/results/" + os.environ.get("FAM_OUT", "face_family"); os.makedirs(OUT, exist_ok=True)
FAM = {}

def run(args):
    cond, s = args; D = c.G[cond]; y = D["y"]; fam = FAM[cond]
    rng = np.random.default_rng(c.SEED + 100 * s + 5000)
    real, fake = np.where(y == 0)[0], np.where(y == 1)[0]; k = min(len(real), len(fake))
    pool = np.r_[rng.choice(real, k, replace=False), rng.choice(fake, k, replace=False)]; rng.shuffle(pool)
    E, L = pool[: len(pool) // 2], pool[len(pool) // 2:]
    src = rng.choice(len(D["ys"]), min(c.NSRC, len(D["ys"])), replace=False); rows = []
    for d in range(NDRAW):
        lab = rng.choice(L, min(N, len(L)), replace=False); A_, C_ = lab[: len(lab) // 2], lab[len(lab) // 2:]
        conf, err = {}, {}
        for t in c.TIERS:
            sc, clf = c.fit_tier(D["Xs"][t][src], D["ys"][src], D["Xt"][t][A_], y[A_], w_t=c.NSRC / len(A_))
            p = clf.predict_proba(sc.transform(D["Xt"][t]))[:, 1]; conf[t] = np.maximum(p, 1 - p); err[t] = (p >= 0.5).astype(int) != y
        for g in ("A", "C"):
            tiers = c.CONFIGS[g]; cE = {t: conf[t][E] for t in tiers}; eE = {t: err[t][E] for t in tiers}
            path = c.build_path(cE, tiers); expE = np.array([c.cascade(cE, eE, tiers, th)[0].mean() for th in path])
            hat = c.certify({t: conf[t][C_] for t in tiers}, {t: err[t][C_] for t in tiers}, tiers, path, c.ALPHA, len(C_), expE, y[C_])
            rel, e, _ = c.cascade(cE, eE, tiers, path[max(hat, 0)])
            if hat < 0: rel[:] = False; e[:] = False
            for f in np.unique(fam[E]):
                m = fam[E] == f
                rows.append(dict(cond=cond, split=s, draw=d, config=g, family=f, n_img=int(m.sum()), release=rel[m].mean(),
                                 err_released=(e[m].sum() / max(rel[m].sum(), 1)), wrong_released_rate=e[m].mean()))
        for t in c.TIERS:
            for f in np.unique(fam[E]):
                m = fam[E] == f
                rows.append(dict(cond=cond, split=s, draw=d, config=f"tier{t}", family=f, n_img=int(m.sum()), release=np.nan,
                                 err_released=err[t][E][m].mean(), wrong_released_rate=np.nan))
    return rows

if __name__ == "__main__":
    t0 = time.time(); man = c.load_manifest()
    man["fam"] = np.where(man["label"] == 0, "REAL:" + man["dataset"].astype(str), man["dataset"].astype(str) + ":" + man["family"].astype(str))
    for cond in c.CONDS:
        Xs, Xt, ys, yt, fam = {}, {}, None, None, None
        for t, models in c.TIERS.items():
            ps, pt = [], []
            for mname in models:
                ko, Xo = c.load_feats("orig", mname); kc, Xc = (ko, Xo) if cond == "orig" else c.load_feats(cond, mname)
                mo, mc = man.reindex(ko), man.reindex(kc)
                srcm = (mo["role"] == "source").values; tgtm = (mc["role"] == "target").values
                pca = c.PCA(min(c.PCADIM, Xo.shape[1] - 1), random_state=c.SEED).fit(Xo[srcm][::2])
                ps.append(pca.transform(Xo[srcm])); pt.append(pca.transform(Xc[tgtm]))
                if ys is None: ys, yt, fam = mo["label"].values[srcm], mc["label"].values[tgtm], mc["fam"].values[tgtm]
            Xs[t], Xt[t] = np.hstack(ps).astype(np.float32), np.hstack(pt).astype(np.float32)
        c.G[cond] = dict(Xs=Xs, Xt=Xt, ys=ys, y=yt); FAM[cond] = fam
        print(cond, "loaded", Xt[3].shape, flush=True)
    jobs = [(cond, s) for cond in c.CONDS for s in range(c.NSPLIT)]
    with get_context("fork").Pool(int(os.environ.get("SLURM_CPUS_PER_TASK", 8))) as pool:
        res = [r for rows in pool.imap_unordered(run, jobs) for r in rows]
    df = pd.DataFrame(res); df.to_csv(f"{OUT}/per_family_draws.csv.gz", index=False)
    summ = df.groupby(["cond", "config", "family"]).agg(n_img=("n_img", "mean"), release=("release", "mean"),
            err_released=("err_released", "mean"), wrong_released_rate=("wrong_released_rate", "mean")).reset_index()
    summ.to_csv(f"{OUT}/per_family.csv", index=False); print(summ.to_string(), flush=True)
    print(f"FAMILY_OK {time.time()-t0:.0f}s")
