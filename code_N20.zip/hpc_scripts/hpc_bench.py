"""Cluster-side benchmark (one L40S): latency, throughput and NVML energy per image for every tier.
Tier 1 MobileNetV3-L, tier 2 ResNet-50 (timm), tier 3 = CLIP ViT-L/14 (OpenAI, QuickGELU) + DINOv2 ViT-L/14,
bf16, channels_last, batch 1/8/64/256. Output: results/system/hpc_bench.json"""
import json, os, statistics, threading, time
import numpy as np, torch, timm, pynvml
torch.backends.cuda.matmul.allow_tf32 = True; torch.backends.cudnn.benchmark = True
R = "/virtiofs/work/bambang/cascade"; OUT = f"{R}/results/system"; os.makedirs(OUT, exist_ok=True)
pynvml.nvmlInit(); H = pynvml.nvmlDeviceGetHandleByIndex(0); dev = "cuda"
res = dict(time=time.strftime("%Y-%m-%d %H:%M:%S"), gpu=torch.cuda.get_device_name(0), torch=torch.__version__,
           driver=pynvml.nvmlSystemGetDriverVersion(), host=os.uname().nodename, models=[])

def load(name):
    if name == "clip_l14":
        import open_clip
        m, _, _ = open_clip.create_model_and_transforms("ViT-L-14-quickgelu", pretrained=None); return m.visual
    if name == "dinov2_l14": return timm.create_model("vit_large_patch14_dinov2.lvd142m", pretrained=False, num_classes=0, img_size=224)
    return timm.create_model(name, pretrained=False, num_classes=2)

def pw(): return pynvml.nvmlDeviceGetPowerUsage(H) / 1000.0

for name in ("mobilenetv3_large_100", "resnet50", "clip_l14", "dinov2_l14"):
    m = load(name).eval().to(dev).to(memory_format=torch.channels_last)
    for bs in (1, 8, 64, 256):
        x = torch.randn(bs, 3, 224, 224, device=dev).contiguous(memory_format=torch.channels_last)
        iters = 300 if bs <= 8 else 60
        with torch.inference_mode(), torch.autocast("cuda", dtype=torch.bfloat16):
            for _ in range(20): m(x)
            torch.cuda.synchronize(); time.sleep(2); idle = statistics.mean([pw() for _ in range(50)])
            vals, stop = [], [False]
            def samp():
                while not stop[0]: vals.append(pw()); time.sleep(0.01)
            th = threading.Thread(target=samp, daemon=True); th.start(); lat = []; t0 = time.perf_counter()
            for _ in range(iters):
                t = time.perf_counter(); m(x); torch.cuda.synchronize(); lat.append((time.perf_counter() - t) * 1000)
            tot = time.perf_counter() - t0; stop[0] = True; th.join()
        p = statistics.mean(vals)
        r = dict(model=name, batch=bs, p50_ms=float(np.percentile(lat, 50)), p95_ms=float(np.percentile(lat, 95)),
                 img_per_s=bs * iters / tot, gpu_power_w=p, gpu_idle_w=idle,
                 gpu_energy_mj_per_img=(p - idle) * tot / (bs * iters) * 1000, gpu_mem_mb=torch.cuda.max_memory_allocated() / 2**20)
        torch.cuda.reset_peak_memory_stats(); res["models"].append(r); print(r, flush=True)
    del m; torch.cuda.empty_cache()
json.dump(res, open(f"{OUT}/hpc_bench.json", "w"), indent=1); print("HPC_BENCH_OK")
