"""J5a: frozen foundation-model embeddings (CLIP ViT-L/14, DINOv2 ViT-L/14) for tar shards.
GPU-optimised: CPU workers only read JPEG bytes; decoding, resize and normalisation run on the GPU
(nvjpeg via torchvision), bf16 autocast, channels_last, large batches. One process per GPU (job array)."""
import os, sys, io, glob, tarfile, time, json
import numpy as np, torch, torchvision
from torchvision.io import decode_jpeg
import torch.nn.functional as F
torch.backends.cuda.matmul.allow_tf32 = True; torch.backends.cudnn.allow_tf32 = True
torch.backends.cudnn.benchmark = True
SHARD_GLOB, OUT, MODEL = sys.argv[1], sys.argv[2], sys.argv[3]          # MODEL: clip_l14 | dinov2_l14
TID, NT = int(os.environ.get("SLURM_ARRAY_TASK_ID", 0)), int(os.environ.get("NTASKS", 1))
BS = int(os.environ.get("BS", 512)); NW = int(os.environ.get("NW", 24))
dev = "cuda"

def load_model():
    if MODEL == "clip_l14":
        import open_clip
        m, _, _ = open_clip.create_model_and_transforms("ViT-L-14-quickgelu", pretrained="openai")   # OpenAI weights need QuickGELU
        enc = m.visual; mean, std = (0.48145466, 0.4578275, 0.40821073), (0.26862954, 0.26130258, 0.27577711)
    else:
        import timm
        name = {"dinov2_l14": "vit_large_patch14_dinov2.lvd142m", "mnv3_l": "mobilenetv3_large_100.ra_in1k",
                "effb0": "efficientnet_b0.ra_in1k", "resnet50": "resnet50.a1_in1k",
                "convnext_t": "convnext_tiny.fb_in1k"}[MODEL]
        kw = {"img_size": 224} if MODEL == "dinov2_l14" else {}
        enc = timm.create_model(name, pretrained=True, num_classes=0, **kw)
        mean, std = (0.485, 0.456, 0.406), (0.229, 0.224, 0.225)
    enc = enc.to(dev).eval().to(memory_format=torch.channels_last)
    return enc, torch.tensor(mean, device=dev).view(1, 3, 1, 1), torch.tensor(std, device=dev).view(1, 3, 1, 1)

class TarBytes(torch.utils.data.IterableDataset):
    def __init__(self, shards): self.shards = shards
    def __iter__(self):
        wi = torch.utils.data.get_worker_info(); k, n = (wi.id, wi.num_workers) if wi else (0, 1)
        for s in self.shards[k::n]:
            with tarfile.open(s) as t:
                for m in t:
                    if m.isfile(): yield os.path.basename(s), m.name, t.extractfile(m).read()   # plain bytes: no shared-memory file descriptors

def collate(b): return b

if __name__ == "__main__":
    shards = sorted(glob.glob(SHARD_GLOB))[TID::NT]
    todo = [s for s in shards if not os.path.exists(f"{OUT}/{MODEL}/{os.path.basename(s)}.npz")]
    os.makedirs(f"{OUT}/{MODEL}", exist_ok=True)
    enc, mean, std = load_model()
    dl = torch.utils.data.DataLoader(TarBytes(todo), batch_size=BS, num_workers=NW, collate_fn=collate,
                                     pin_memory=False, prefetch_factor=4, persistent_workers=NW > 0)
    buf = {}; t0 = time.time(); n = 0
    with torch.inference_mode(), torch.autocast("cuda", dtype=torch.bfloat16):
        for batch in dl:
            imgs = decode_jpeg([torch.frombuffer(bytearray(x[2]), dtype=torch.uint8) for x in batch], device=dev)                 # nvjpeg batch decode
            x = F.interpolate(torch.stack(imgs).float(), size=(224, 224), mode="bicubic", antialias=True) if len({i.shape for i in imgs}) == 1 else torch.stack([F.interpolate(i[None].float(), size=(224, 224), mode="bicubic", antialias=True)[0] for i in imgs])   # one batched resize
            x = ((x / 255.0 - mean) / std).contiguous(memory_format=torch.channels_last)
            z = enc(x).float().cpu().numpy().astype(np.float16)
            for (shard, key, _), v in zip(batch, z): buf.setdefault(shard, []).append((key, v))
            n += len(batch)
            if n % (BS * 20) < BS: print(f"{n} img  {n/(time.time()-t0):.0f} img/s", flush=True)
    for shard, items in buf.items():
        np.savez(f"{OUT}/{MODEL}/{shard}.npz", keys=np.array([k for k, _ in items]), emb=np.stack([v for _, v in items]))
    print(f"EXTRACT_OK {MODEL} {n} img {n/(time.time()-t0):.0f} img/s")
