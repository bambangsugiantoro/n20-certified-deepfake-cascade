#!/bin/bash
# Run on the login node (has internet): cache model weights so compute jobs need no internet.
R=/virtiofs/work/bambang/cascade; export HF_HOME=$R/env/hf
apptainer exec $R/env/pytorch.sif $R/env/venv/bin/python -c "
import open_clip, timm
open_clip.create_model_and_transforms('ViT-L-14', pretrained='openai')
timm.create_model('vit_large_patch14_dinov2.lvd142m', pretrained=True, num_classes=0)
print('WEIGHTS_OK')"
