#!/bin/bash
#SBATCH -J pilot_ctc
#SBATCH -p l40s
#SBATCH --gres=gpu:2
#SBATCH -c 64
#SBATCH --mem=200G
#SBATCH -t 12:00:00
#SBATCH -o /virtiofs/work/bambang/cascade/logs/%x_%j.out
# Pilot CTC on Community Forensics Eval: (1) tier-1/2 features (MobileNetV3-L, ResNet-50) on both GPUs,
# (2) certification experiment on 60 CPU workers. Uses existing CLIP features for tier 3.
set -uo pipefail
ulimit -n 65536 2>/dev/null || true
R=/virtiofs/work/bambang/cascade; cd $R
export HF_HOME=$R/env/hf OMP_NUM_THREADS=2 NTASKS=2 BS=512 NW=14
RUN="apptainer exec --nv $R/env/pytorch.sif $R/env/venv/bin/python"
for M in mnv3_l resnet50; do
  for COND in orig c; do
    for G in 0 1; do
      CUDA_VISIBLE_DEVICES=$G SLURM_ARRAY_TASK_ID=$G $RUN $R/scripts/extract_frozen.py "$R/data/proc/cf_eval/$COND/*.tar" $R/feats/cf_eval/$COND $M &
    done; wait
  done
done
echo "== features done $(date)"
SLURM_CPUS_PER_TASK=60 OMP_NUM_THREADS=1 $RUN $R/scripts/ctc_pilot.py
