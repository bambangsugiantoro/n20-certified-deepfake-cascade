#!/bin/bash
#SBATCH -J env
#SBATCH -p l40s
#SBATCH -c 16
#SBATCH --mem=64G
#SBATCH -t 04:00:00
#SBATCH -o /virtiofs/work/bambang/cascade/logs/%x_%j.out
# Build the software environment once: NGC PyTorch container + a venv with extras.
set -euo pipefail
R=/virtiofs/work/bambang/cascade
export APPTAINER_CACHEDIR=$R/env/cache APPTAINER_TMPDIR=$R/env/tmp
mkdir -p $APPTAINER_CACHEDIR $APPTAINER_TMPDIR
SIF=$R/env/pytorch.sif
if [ -n "${EXISTING_SIF:-}" ] && [ -f "$EXISTING_SIF" ]; then ln -sf "$EXISTING_SIF" $SIF; fi
[ -f $SIF ] || apptainer pull $SIF docker://nvcr.io/nvidia/pytorch:25.08-py3
apptainer exec $SIF python -m venv --system-site-packages $R/env/venv
apptainer exec $SIF $R/env/venv/bin/pip install -q --upgrade \
  open_clip_torch timm huggingface_hub hf_transfer datasets pyarrow imagehash nvidia-ml-py webdataset
apptainer exec --nv $SIF $R/env/venv/bin/python -c "import torch,open_clip,timm;print(torch.__version__, open_clip.__version__, timm.__version__)"
echo ENV_OK
