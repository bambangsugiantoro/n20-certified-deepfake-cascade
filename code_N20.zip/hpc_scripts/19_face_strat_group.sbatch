#!/bin/bash
#SBATCH -J strat_group
#SBATCH -p l40s
#SBATCH -c 120
#SBATCH --mem=400G
#SBATCH -t 1-00:00:00
#SBATCH -o /virtiofs/work/bambang/cascade/logs/%x_%j.out
# (1) stratified labelling (half reals / half fakes) for low prevalence; (2) group-conditional certification
# (miss rate <= 10 % for EVERY target fake family, Bonferroni over families). Data = face incl. DiFF reals.
R=/virtiofs/work/bambang/cascade; cd $R
RUN="apptainer exec $R/env/pytorch.sif $R/env/venv/bin/python"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 SLURM_CPUS_PER_TASK=118 DS=face RISK=cc DELTA_CC=0.05,0.10 WEIGHTS=0.1,0.1,0.8 CONDS=orig,rs,jpg,c
export TIERS_JSON='{"1": ["mnv3_l_face"], "2": ["resnet50_face"], "3": ["clip_l14", "dinov2_l14"]}'
PILOT_NAME=face_strat STRAT=1 GROUP=0 PREVS=0.1,0.01 BUDGETS=800,3200,6400,12800 $RUN scripts/ctc_pilot2.py > logs/face_strat.log 2>&1
PILOT_NAME=face_group STRAT=1 GROUP=1 PREVS=0.5,0.1 BUDGETS=3200,6400,12800 $RUN scripts/ctc_pilot2.py > logs/face_group.log 2>&1
tail -1 logs/face_strat.log logs/face_group.log; echo STRAT_GROUP_OK
