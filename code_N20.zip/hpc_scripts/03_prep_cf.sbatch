#!/bin/bash
#SBATCH -J prep_cf
#SBATCH -p l40s
#SBATCH -c 96
#SBATCH --mem=192G
#SBATCH -t 12:00:00
#SBATCH -o /virtiofs/work/bambang/cascade/logs/%x_%j.out
# J2: CPU-heavy preprocessing on 96 cores (leaves 32 cores for GPU data loaders running alongside).
set -euo pipefail
R=/virtiofs/work/bambang/cascade
export OMP_NUM_THREADS=1
apptainer exec $R/env/pytorch.sif $R/env/venv/bin/python $R/scripts/prep_parquet.py \
  $R/data/raw/cf_eval $R/data/proc/cf_eval
