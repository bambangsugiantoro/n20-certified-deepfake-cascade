#!/bin/bash
#SBATCH -J diffreal
#SBATCH -p l40s
#SBATCH --gres=gpu:2
#SBATCH -c 96
#SBATCH --mem=400G
#SBATCH -t 1-00:00:00
#SBATCH -o /virtiofs/work/bambang/cascade/logs/%x_%j.out
# DiFF real integration: new shards -> frozen + fine-tuned features (2 GPUs) -> face_cc2 (all targets) + face_cc_diff (DiFF-only) + per-family
set -e
R=/virtiofs/work/bambang/cascade; cd $R; ulimit -n 65536 2>/dev/null || true
RUN="apptainer exec --nv $R/env/pytorch.sif $R/env/venv/bin/python"
export HF_HOME=$R/env/hf OMP_NUM_THREADS=1
SLURM_CPUS_PER_TASK=90 $RUN scripts/prep_face_add.py
for COND in orig c rs jpg; do
  for M in clip_l14 dinov2_l14; do
    SLURM_ARRAY_TASK_ID=0 NTASKS=2 NW=14 CUDA_VISIBLE_DEVICES=0 $RUN scripts/extract_frozen.py "$R/data/proc/face/$COND/*.tar" $R/feats/face/$COND $M &
    SLURM_ARRAY_TASK_ID=1 NTASKS=2 NW=14 CUDA_VISIBLE_DEVICES=1 $RUN scripts/extract_frozen.py "$R/data/proc/face/$COND/*.tar" $R/feats/face/$COND $M &
    wait
  done
done
CUDA_VISIBLE_DEVICES=0 $RUN scripts/feat_ft_new.py mobilenetv3_large_100.ra_in1k mnv3_l_face &
CUDA_VISIBLE_DEVICES=1 $RUN scripts/feat_ft_new.py resnet50.a1_in1k resnet50_face &
wait
export OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 DS=face RISK=cc DELTA_CC=0.05,0.10 WEIGHTS=0.1,0.1,0.8 CONDS=orig,rs,jpg,c
export TIERS_JSON='{"1": ["mnv3_l_face"], "2": ["resnet50_face"], "3": ["clip_l14", "dinov2_l14"]}'
SLURM_CPUS_PER_TASK=94 PILOT_NAME=face_cc2 PREVS=0.5,0.1,0.01 BUDGETS=800,3200,6400,12800 $RUN scripts/ctc_pilot2.py > logs/face_cc2.log 2>&1
SLURM_CPUS_PER_TASK=94 PILOT_NAME=face_cc_diff TGT_DATASET=diff PREVS=0.5,0.1 BUDGETS=800,3200,6400 $RUN scripts/ctc_pilot2.py > logs/face_cc_diff.log 2>&1
SLURM_CPUS_PER_TASK=40 FAM_OUT=face_family2 $RUN scripts/per_family.py > logs/face_family2.log 2>&1
tail -2 logs/face_cc2.log logs/face_cc_diff.log logs/face_family2.log; echo DIFFREAL_CHAIN_OK
