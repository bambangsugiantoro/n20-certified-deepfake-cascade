#!/bin/bash
#SBATCH -J hpc_bench
#SBATCH -p l40s
#SBATCH --gres=gpu:1
#SBATCH -c 16
#SBATCH --mem=64G
#SBATCH -t 02:00:00
#SBATCH -o /virtiofs/work/bambang/cascade/logs/%x_%j.out
# J6 cluster side: per-tier latency / throughput / NVML energy on one L40S (exclusive GPU)
R=/virtiofs/work/bambang/cascade; cd $R
RUN="apptainer exec --nv $R/env/pytorch.sif $R/env/venv/bin/python"
$RUN -c "import pynvml" 2>/dev/null || $RUN -m pip install --quiet nvidia-ml-py
nvidia-smi --query-gpu=name,driver_version,power.limit,clocks.max.sm --format=csv
$RUN $R/scripts/hpc_bench.py
