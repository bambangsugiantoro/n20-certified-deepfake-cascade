"""Fine-tune a cheap tier (timm backbone) on the SOURCE generators of Community Forensics Eval, then
write penultimate features for every image and compression condition (same .npz format as extract_frozen).
Usage: finetune_tier.py <timm_name> <out_name>   (one GPU; run two in parallel on two GPUs)
Training: orig condition, source = non-commercial generators + their paired reals; light augmentation
(random resized crop, flip, random JPEG recompression) so compression robustness is learned on source only."""
import os, sys, io, glob, tarfile, time, random
import numpy as np, pandas as pd, torch, torch.nn as nn, torch.nn.functional as F
from PIL import Image
import timm
torch.backends.cudnn.benchmark = True
torch.backends.cuda.matmul.allow_tf32 = True; torch.backends.cudnn.allow_tf32 = True
R = "/virtiofs/work/bambang/cascade"
TIMM, NAME = sys.argv[1], sys.argv[2]
EPOCHS, BS, LR, NW = int(os.environ.get("EPOCHS", 6)), 128, 3e-4, int(os.environ.get("NW", 14))
SEED = 20261113; random.seed(SEED); np.random.seed(SEED); torch.manual_seed(SEED)
MEAN = torch.tensor([0.485, 0.456, 0.406]).view(3, 1, 1); STD = torch.tensor([0.229, 0.224, 0.225]).view(3, 1, 1)

DS = os.environ.get("DS", "cf_eval")
man = pd.concat([pd.read_csv(f) for f in glob.glob(f"{R}/data/proc/{DS}/manifest/*.csv")])
if "role" not in man: man["role"] = np.where(man["architecture"] == "Commercial", "target", "source")
LAB = dict(zip(man["key"], man["label"].astype(int))); SRC = set(man.loc[man["role"] == "source", "key"])

def read_tar(path, keep=None):
    out = []
    with tarfile.open(path) as t:
        for m in t:
            if m.isfile():
                k = m.name.removesuffix(".jpg")
                if keep is None or k in keep: out.append((k, t.extractfile(m).read()))
    return out

def to_tensor(im):
    x = torch.from_numpy(np.asarray(im, dtype=np.uint8).copy()).permute(2, 0, 1).float() / 255.
    return (x - MEAN) / STD

class Train(torch.utils.data.Dataset):
    def __init__(self, items): self.items = items
    def __len__(self): return len(self.items)
    def __getitem__(self, i):
        k, b = self.items[i]; im = Image.open(io.BytesIO(b)).convert("RGB")
        s = random.uniform(0.6, 1.0); w = int(256 * s); x0, y0 = random.randint(0, 256 - w), random.randint(0, 256 - w)
        im = im.crop((x0, y0, x0 + w, y0 + w)).resize((224, 224), Image.BICUBIC)
        if random.random() < 0.5: im = im.transpose(Image.FLIP_LEFT_RIGHT)
        if random.random() < 0.5:
            buf = io.BytesIO(); im.save(buf, "JPEG", quality=random.randint(50, 95)); im = Image.open(buf).convert("RGB")
        return to_tensor(im), LAB[k]

class Eval(torch.utils.data.Dataset):
    def __init__(self, items): self.items = items
    def __len__(self): return len(self.items)
    def __getitem__(self, i):
        k, b = self.items[i]; im = Image.open(io.BytesIO(b)).convert("RGB").resize((224, 224), Image.BICUBIC)
        return to_tensor(im), i

if __name__ == "__main__":
    t0 = time.time(); dev = "cuda"
    shards = sorted(glob.glob(f"{R}/data/proc/{DS}/orig/*.tar"))
    items = [it for s in shards for it in read_tar(s, SRC)]
    random.shuffle(items); nva = len(items) // 10; va, tr = items[:nva], items[nva:]
    print(f"{NAME}: train {len(tr)} val {len(va)} ({time.time()-t0:.0f}s)", flush=True)
    model = timm.create_model(TIMM, pretrained=True, num_classes=2).to(dev).to(memory_format=torch.channels_last)
    opt = torch.optim.AdamW(model.parameters(), lr=LR, weight_decay=0.05)
    dl = torch.utils.data.DataLoader(Train(tr), batch_size=BS, shuffle=True, num_workers=NW, pin_memory=True, drop_last=True, persistent_workers=True)
    sched = torch.optim.lr_scheduler.OneCycleLR(opt, max_lr=LR, total_steps=EPOCHS * len(dl), pct_start=0.1)
    dlv = torch.utils.data.DataLoader(Eval(va), batch_size=256, num_workers=NW)
    best, best_state = -1, None
    for ep in range(EPOCHS):
        model.train()
        for x, y in dl:
            x, y = x.to(dev, non_blocking=True).to(memory_format=torch.channels_last), y.to(dev)
            with torch.autocast("cuda", dtype=torch.bfloat16): loss = F.cross_entropy(model(x), y)
            opt.zero_grad(set_to_none=True); loss.backward(); opt.step(); sched.step()
        model.eval(); correct = 0
        with torch.inference_mode(), torch.autocast("cuda", dtype=torch.bfloat16):
            for x, i in dlv:
                p = model(x.to(dev).to(memory_format=torch.channels_last)).argmax(1).cpu()
                correct += (p.numpy() == np.array([LAB[va[j][0]] for j in i.numpy()])).sum()
        acc = correct / len(va); print(f"epoch {ep} loss {loss.item():.3f} src_val_acc {acc:.4f} ({time.time()-t0:.0f}s)", flush=True)
        if acc > best: best, best_state = acc, {k: v.detach().clone() for k, v in model.state_dict().items()}
    model.load_state_dict(best_state); os.makedirs(f"{R}/models", exist_ok=True)
    torch.save(best_state, f"{R}/models/{NAME}.pt")
    model.reset_classifier(0); model.eval()
    for cond in ["orig", "rs", "jpg", "c"]:
        od = f"{R}/feats/{DS}/{cond}/{NAME}"; os.makedirs(od, exist_ok=True)
        shards = sorted(glob.glob(f"{R}/data/proc/{DS}/{cond}/*.tar")); its, owner = [], []
        for s in shards:
            for it in read_tar(s): its.append(it); owner.append(os.path.basename(s))
        feats = []
        with torch.inference_mode(), torch.autocast("cuda", dtype=torch.bfloat16):
            for x, i in torch.utils.data.DataLoader(Eval(its), batch_size=512, num_workers=NW):
                feats.append(model(x.to(dev).to(memory_format=torch.channels_last)).float().cpu().numpy().astype(np.float16))
        feats = np.concatenate(feats); owner = np.array(owner); keys = np.array([k + ".jpg" for k, _ in its])
        for s in np.unique(owner):
            m = owner == s; np.savez(f"{od}/{s}.npz", keys=keys[m], emb=feats[m])
        print(f"features {cond} done ({time.time()-t0:.0f}s)", flush=True)
    print(f"FINETUNE_OK {NAME} best_src_val_acc {best:.4f} {time.time()-t0:.0f}s")
