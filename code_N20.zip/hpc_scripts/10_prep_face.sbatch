#!/bin/bash
#SBATCH -J prep_face
#SBATCH -p l40s
#SBATCH -c 96
#SBATCH --mem=192G
#SBATCH -t 12:00:00
#SBATCH -o /virtiofs/work/bambang/cascade/logs/%x_%j.out
# J2-face: family-split selection + 4 compression conditions as tar shards (CPU, 96 cores)
set -euo pipefail
R=/virtiofs/work/bambang/cascade; cd $R
export OMP_NUM_THREADS=1
apptainer exec $R/env/pytorch.sif $R/env/venv/bin/python $R/scripts/prep_face.py
