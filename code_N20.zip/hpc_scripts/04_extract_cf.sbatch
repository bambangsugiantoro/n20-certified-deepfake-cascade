#!/bin/bash
#SBATCH -J ext_cf
#SBATCH -p l40s
#SBATCH --array=0-1
#SBATCH --gres=gpu:1
#SBATCH -c 16
#SBATCH --mem=96G
#SBATCH -t 12:00:00
#SBATCH -o /virtiofs/work/bambang/cascade/logs/%x_%A_%a.out
# J5a: one task per L40S (2 tasks run in parallel); 16 CPU workers per GPU only read bytes, GPU decodes.
set -euo pipefail
R=/virtiofs/work/bambang/cascade
export HF_HOME=$R/env/hf NTASKS=2 BS=${BS:-512} NW=${NW:-14} OMP_NUM_THREADS=2
for COND in orig c rs jpg; do
  for M in clip_l14 dinov2_l14; do
    apptainer exec --nv $R/env/pytorch.sif $R/env/venv/bin/python $R/scripts/extract_frozen.py \
      "$R/data/proc/cf_eval/$COND/*.tar" $R/feats/cf_eval/$COND $M
  done
done
