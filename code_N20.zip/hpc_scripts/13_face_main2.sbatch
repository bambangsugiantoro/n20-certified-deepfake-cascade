#!/bin/bash
#SBATCH -J face_main2
#SBATCH -p l40s
#SBATCH -c 120
#SBATCH --mem=400G
#SBATCH -t 1-00:00:00
#SBATCH -o /virtiofs/work/bambang/cascade/logs/%x_%j.out
# Face main run 2 (CPU): adds weighted alpha split SETW (A 0.1, B 0.1, C 0.8 of alpha) and larger label budgets
R=/virtiofs/work/bambang/cascade; cd $R
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 SLURM_CPUS_PER_TASK=118 DS=face
export PILOT_NAME=face_main2 CONDS=orig,rs,jpg,c PREVS=0.5,0.1,0.01 BUDGETS=800,3200,6400,12800 WEIGHTS=0.1,0.1,0.8
export TIERS_JSON='{"1": ["mnv3_l_face"], "2": ["resnet50_face"], "3": ["clip_l14", "dinov2_l14"]}'
apptainer exec $R/env/pytorch.sif $R/env/venv/bin/python $R/scripts/ctc_pilot2.py
