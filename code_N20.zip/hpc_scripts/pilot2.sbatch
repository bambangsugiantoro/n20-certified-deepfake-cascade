#!/bin/bash
#SBATCH -J pilot2_ctc
#SBATCH -p l40s
#SBATCH -c 64
#SBATCH --mem=240G
#SBATCH -t 12:00:00
#SBATCH -o /virtiofs/work/bambang/cascade/logs/%x_%j.out
# Pilot v2: Adapt+CTC on Community Forensics Eval (CPU only; features already extracted).
R=/virtiofs/work/bambang/cascade; cd $R
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 SLURM_CPUS_PER_TASK=62
apptainer exec $R/env/pytorch.sif $R/env/venv/bin/python $R/scripts/ctc_pilot2.py
