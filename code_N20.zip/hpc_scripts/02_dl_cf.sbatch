#!/bin/bash
#SBATCH -J dl_cf
#SBATCH -p l40s
#SBATCH -c 8
#SBATCH --mem=16G
#SBATCH -t 1-00:00:00
#SBATCH -o /virtiofs/work/bambang/cascade/logs/%x_%j.out
# J1: download Community Forensics Eval (~206 GB). Uses few CPUs so GPU/CPU jobs can run alongside.
set -euo pipefail
R=/virtiofs/work/bambang/cascade
export HF_HOME=$R/env/hf NW=16
apptainer exec $R/env/pytorch.sif $R/env/venv/bin/python $R/scripts/dl_hf.py \
  OwensLab/CommunityForensics-Eval $R/data/raw/cf_eval
du -sh $R/data/raw/cf_eval
