#!/bin/bash
#SBATCH -J probe
#SBATCH -p l40s
#SBATCH --gres=gpu:1
#SBATCH -c 4
#SBATCH --mem=8G
#SBATCH -t 00:10:00
#SBATCH -o /virtiofs/work/bambang/cascade/logs/%x_%j.out
# Read-only probe of the compute node.
echo "== host"; hostname; lscpu | egrep 'Model name|Socket|Core|Thread|NUMA'
echo "== gpu"; nvidia-smi; nvidia-smi topo -m; nvidia-smi --query-gpu=name,memory.total,power.limit,clocks.max.sm --format=csv
echo "== net"; curl -sI -m 10 https://huggingface.co | head -1; curl -sI -m 10 https://nvcr.io/v2/ | head -1
echo "== containers"; find /virtiofs/work/bambang -maxdepth 4 -name '*.sif' 2>/dev/null | head; ls /share/software 2>/dev/null | head -30
echo "== local disk"; df -h /tmp /dev/shm
