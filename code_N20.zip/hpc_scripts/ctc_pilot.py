"""Pilot of certified edge-cluster cascades (CTC) on Community Forensics Eval.

Generator shift: detectors (linear probes on frozen backbones) are trained only on non-commercial
generators (GAN, latent/pixel diffusion, Stable Cascade) and their paired real images; the target is
the commercial generators (Midjourney, DALL-E, FLUX, Firefly, Ideogram, Imagen) with their paired reals.

Tiers: 1 = MobileNetV3-L (edge), 2 = ResNet-50, 3 = CLIP ViT-L/14 (cluster).
Configurations certified together with alpha/G each on ONE label pool: A = 1>2>3, B = 1>3, C = 3.
Certification: label-free cost-aware threshold path (nested release sets) + fixed-sequence Clopper-Pearson.
Outputs: results/pilot/summary.csv and per-draw CSV.
"""
import os, sys, glob, json, math, time
import numpy as np, pandas as pd
from multiprocessing import Pool
from scipy.stats import beta
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.isotonic import IsotonicRegression

R = os.environ.get("R", "/virtiofs/work/bambang/cascade")
OUT = f"{R}/results/pilot"; os.makedirs(OUT, exist_ok=True)
TIERS = {1: "mnv3_l", 2: "resnet50", 3: "clip_l14"}
COST = {1: 0.22, 2: 4.1, 3: 81.0}           # GFLOPs at 224px (proxy; replaced by measured GPU-seconds in J6)
CONFIGS = {"A": [1, 2, 3], "B": [1, 3], "C": [3]}
ALPHA, DELTA, GRID = 0.05, 0.05, 20
BUDGETS = [100, 200, 400, 800]
PREVS = [0.5, 0.1, 0.01]
CONDS = ["orig", "c"]
NSPLIT, NDRAW = 20, 50
SEED = 20261112

def load_manifest():
    fs = sorted(glob.glob(f"{R}/data/proc/cf_eval/manifest/*.csv"))
    m = pd.concat([pd.read_csv(f, usecols=["key", "label", "model_name", "architecture"]) for f in fs], ignore_index=True)
    m["label"] = m["label"].astype(int)
    return m.set_index("key")

def load_feats(cond, model):
    keys, embs = [], []
    for f in sorted(glob.glob(f"{R}/feats/cf_eval/{cond}/{model}/*.npz")):
        z = np.load(f); keys += [k.removesuffix(".jpg") for k in z["keys"]]; embs.append(z["emb"].astype(np.float32))
    return pd.Index(keys), np.concatenate(embs)

def train_probe(Xtr, ytr, Xva, yva):
    sc = StandardScaler().fit(Xtr); best = None
    for C in (0.01, 0.1, 1.0):
        clf = LogisticRegression(C=C, max_iter=3000).fit(sc.transform(Xtr), ytr)
        acc = (clf.predict(sc.transform(Xva)) == yva).mean()
        if best is None or acc > best[0]: best = (acc, C, clf)
    return sc, best[2], best[0], best[1]

def cp_upper(k, m, a):
    return 1.0 if m == 0 else (1.0 if k >= m else beta.ppf(1 - a, k + 1, m - k))

def release_matrix(conf, err, tiers, path):
    """conf/err: dict tier -> (N,) arrays. path: (M, len(tiers)) thresholds. Returns released (N,M), error (N,M), cost (N,M)."""
    N, M = len(next(iter(conf.values()))), len(path)
    released = np.zeros((N, M), bool); error = np.zeros((N, M), bool); cost = np.zeros((N, M))
    alive = np.ones((N, M), bool)
    for j, t in enumerate(tiers):
        cost += alive * COST[t]
        hit = alive & (conf[t][:, None] >= path[None, :, j])
        released |= hit; error |= hit & err[t][:, None]; alive &= ~hit
    return released, error, cost

def build_path(conf_E, tiers, errhat_E, cost_aware=True):
    """Label-free, monotone (non-increasing) threshold path from the design pool U_E.
    Each step lowers ONE tier's threshold by one quantile step, choosing the move with the best
    gain in release, minus a cost penalty and an estimated-error penalty. errhat_E[t] is a
    source-calibrated (isotonic) estimate of P(error | confidence): no target labels are used."""
    q = {t: np.r_[np.inf, np.quantile(conf_E[t], 1 - np.arange(1, GRID + 1) / GRID)] for t in tiers}
    j = [0] * len(tiers); path = [[q[t][0] for t in tiers]]
    def stats(js):
        alive = np.ones(len(conf_E[tiers[0]]), bool); rel = np.zeros_like(alive); c = np.zeros(len(alive)); e = 0.0
        for i, t in enumerate(tiers):
            c += alive * COST[t]; hit = alive & (conf_E[t] >= q[t][js[i]])
            e += errhat_E[t][hit].sum(); rel |= hit; alive &= ~hit
        n = len(alive); return rel.mean(), c.mean() / COST[tiers[-1]], e / n
    r0, c0, e0 = stats(j)
    while any(x < GRID for x in j):
        if not cost_aware:
            j = [min(x + 1, GRID) for x in j]
        else:
            best = None
            for i in range(len(tiers)):
                if j[i] >= GRID: continue
                cand = j.copy(); cand[i] += 1; r, c, e = stats(cand)
                score = (r - r0) - 0.5 * (c - c0) - (e - e0) / DELTA
                if best is None or score > best[0]: best = (score, cand, r, c, e)
            j, r0, c0, e0 = best[1], best[2], best[3], best[4]
        path.append([q[t][j[i]] for i, t in enumerate(tiers)])
    return np.array(path)

def certify(rel_L, err_L, idx, exp_rel, a, n):
    """Fixed-sequence CP test along the path; returns last certified index or -1."""
    mmin = math.ceil(math.log(a) / math.log(1 - DELTA)); hat = -1
    for lam in range(rel_L.shape[1]):
        if n * exp_rel[lam] < mmin: continue                      # skip set fixed before labels
        m = rel_L[idx, lam].sum(); k = err_L[idx, lam].sum()
        if cp_upper(k, m, a) <= DELTA: hat = lam
        else: break
    return hat

def run_split(args):
    s, cond, prev, data = args
    rng = np.random.default_rng(SEED + 1000 * s + int(prev * 1000) + (0 if cond == "orig" else 7))
    y, conf, err, eh = data["y"], data["conf"], data["err"], data["errhat"]
    real, fake = np.where(y == 0)[0], np.where(y == 1)[0]
    if prev >= 0.5: nr = nf = min(len(real), len(fake))
    else: nr, nf = len(real), min(len(fake), int(round(len(real) * prev / (1 - prev))))
    pool = np.r_[rng.choice(real, nr, replace=False), rng.choice(fake, nf, replace=False)]
    rng.shuffle(pool); E, L = pool[: len(pool) // 2], pool[len(pool) // 2:]
    rows = []
    paths = {}
    for g, tiers in CONFIGS.items():
        cE = {t: conf[t][E] for t in tiers}; eE = {t: err[t][E] for t in tiers}
        path = build_path(cE, tiers, {t: eh[t][E] for t in tiers})
        relE, errE, costE = release_matrix(cE, eE, tiers, path)
        relL, errL, _ = release_matrix({t: conf[t][L] for t in tiers}, {t: err[t][L] for t in tiers}, tiers, path)
        paths[g] = (relE, errE, costE, relL, errL, relE.mean(0))
    # uncertified heuristic cascade A: release when confidence >= 0.9 at each tier
    hA = np.array([[0.9, 0.9, 0.9]])
    hr, he, hc = release_matrix({t: conf[t][E] for t in CONFIGS["A"]}, {t: err[t][E] for t in CONFIGS["A"]}, CONFIGS["A"], hA)
    for n in BUDGETS:
        for d in range(NDRAW):
            idx = rng.choice(len(L), min(n, len(L)), replace=False)
            certs = {}
            for g in CONFIGS:
                relE, errE, costE, relL, errL, expr = paths[g]
                for mode, a in (("set", ALPHA / len(CONFIGS)), ("alone", ALPHA)):
                    hat = certify(relL, errL, idx, expr, a, n)
                    if hat < 0: rr, risk, cst = 0.0, np.nan, costE[:, 0].mean()
                    else:
                        r = relE[:, hat]; rr = r.mean(); risk = errE[r, hat].mean() if r.any() else np.nan; cst = costE[:, hat].mean()
                    certs[(g, mode)] = (rr, risk, cst)
                    rows.append(dict(split=s, cond=cond, prev=prev, n=n, draw=d, config=g, mode=mode,
                                     release=rr, risk=risk, cost_gflops=cst, valid=bool(np.isnan(risk) or risk <= DELTA)))
            anybad = any(not (np.isnan(certs[(g, "set")][1]) or certs[(g, "set")][1] <= DELTA) for g in CONFIGS)
            rows.append(dict(split=s, cond=cond, prev=prev, n=n, draw=d, config="SET", mode="set",
                             release=max(certs[(g, "set")][0] for g in CONFIGS), risk=np.nan, cost_gflops=np.nan, valid=not anybad))
    rows.append(dict(split=s, cond=cond, prev=prev, n=-1, draw=-1, config="A_heuristic0.9", mode="uncertified",
                     release=hr.mean(), risk=he[hr[:, 0], 0].mean() if hr.any() else np.nan, cost_gflops=hc.mean(),
                     valid=bool(he[hr[:, 0], 0].mean() <= DELTA) if hr.any() else True))
    return rows

if __name__ == "__main__":
    t0 = time.time(); man = load_manifest()
    src_mask = man["architecture"] != "Commercial"
    print("source", int(src_mask.sum()), "target", int((~src_mask).sum()), flush=True)
    det = []
    jobs = []
    for cond in CONDS:
        conf, err, errhat, y_t = {}, {}, {}, None
        for t, mname in TIERS.items():
            ko, Xo = load_feats("orig", mname); kc, Xc = (ko, Xo) if cond == "orig" else load_feats(cond, mname)
            mo = man.reindex(ko); mc = man.reindex(kc)
            src = np.where((mo["architecture"] != "Commercial").values)[0]
            rng = np.random.default_rng(SEED + t); rng.shuffle(src)
            tr, va = src[: int(.75 * len(src))], src[int(.75 * len(src)):]
            sc, clf, vacc, C = train_probe(Xo[tr], mo["label"].values[tr], Xo[va], mo["label"].values[va])
            tgt = np.where((mc["architecture"] == "Commercial").values)[0]
            order = np.argsort(kc[tgt]); tgt = tgt[order]
            pv = clf.predict_proba(sc.transform(Xo[va]))[:, 1]; yv = mo["label"].values[va]
            iso = IsotonicRegression(increasing=False, out_of_bounds="clip", y_min=0, y_max=1).fit(
                np.maximum(pv, 1 - pv), ((pv >= 0.5).astype(int) != yv).astype(float))
            p = clf.predict_proba(sc.transform(Xc[tgt]))[:, 1]; y = mc["label"].values[tgt]
            conf[t] = np.maximum(p, 1 - p); err[t] = (p >= 0.5).astype(int) != y; errhat[t] = iso.predict(conf[t])
            if y_t is None: y_t = y
            assert (y_t == y).all()
            from sklearn.metrics import roc_auc_score
            det.append(dict(cond=cond, tier=t, model=mname, C=C, src_val_acc=vacc, tgt_acc=1 - err[t].mean(),
                            tgt_auc=roc_auc_score(y, p), tgt_n=len(y)))
            print(det[-1], flush=True)
        data = dict(y=y_t, conf=conf, err=err, errhat=errhat)
        jobs += [(s, cond, prev, data) for prev in PREVS for s in range(NSPLIT)]
    pd.DataFrame(det).to_csv(f"{OUT}/detectors.csv", index=False)
    ncpu = int(os.environ.get("SLURM_CPUS_PER_TASK", 8))
    with Pool(ncpu) as pool:
        res = [r for rows in pool.imap_unordered(run_split, jobs) for r in rows]
    df = pd.DataFrame(res); df.to_csv(f"{OUT}/draws.csv.gz", index=False)
    g = df.groupby(["cond", "prev", "n", "config", "mode"])
    summ = g.agg(validity=("valid", "mean"), release=("release", "mean"), risk=("risk", "mean"),
                 cost_gflops=("cost_gflops", "mean"), draws=("valid", "size")).reset_index()
    summ.to_csv(f"{OUT}/summary.csv", index=False)
    print(summ.to_string(), flush=True)
    print(f"PILOT_OK {time.time()-t0:.0f}s")
