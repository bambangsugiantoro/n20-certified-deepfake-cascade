@echo off
setlocal
cd /d "%~dp0"
echo === Pasang PyTorch versi GPU (CUDA) lalu ulang benchmark ===
if not exist .venv\Scripts\activate.bat (echo Jalankan run_edge.bat dulu. & pause & exit /b 1)
call .venv\Scripts\activate.bat
nvidia-smi
for %%C in (cu130 cu128 cu126) do (
  python -c "import torch,sys; sys.exit(0 if torch.cuda.is_available() else 1)" 2>nul && goto :ok
  echo Mencoba PyTorch %%C ...
  python -m pip install --force-reinstall --no-deps torch torchvision --index-url https://download.pytorch.org/whl/%%C
)
python -c "import torch,sys; sys.exit(0 if torch.cuda.is_available() else 1)" 2>nul || (echo GPU tetap tidak terdeteksi oleh PyTorch. Kirim layar ini ke Claude. & pause & exit /b 1)
:ok
python -c "import torch; print('PyTorch', torch.__version__, 'CUDA', torch.version.cuda, torch.cuda.get_device_name(0))"
python edge_bench.py
echo.
echo Selesai. Hasil: %~dp0edge_results.json
pause
