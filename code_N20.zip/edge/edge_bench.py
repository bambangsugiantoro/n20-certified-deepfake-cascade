"""Edge benchmark for the certified edge-cluster cascade (tier 1 MobileNetV3-L, tier 2 ResNet-50).
Runs on the edge laptop (Windows, RTX 3050 Laptop 4 GB, i7-1260P). Measures, per model and device:
  - latency p50/p95 (batch 1 and 8), throughput, fp16 on GPU / fp32 on CPU
  - GPU energy per image from NVML power sampling (minus idle power)
  - CPU preprocessing time (JPEG decode + resize 224) for a 256x256 JPEG
  - network to the cluster: TCP connect RTT and HTTPS round-trip to hpc.uin-suka.ac.id, JPEG payload sizes
Latency does not depend on the trained weights, so random-initialised timm models are used (no download).
Output: edge_results.json next to this script."""
import io, json, os, platform, socket, ssl, statistics, threading, time, urllib.request
import numpy as np, torch, timm
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__)); OUT = os.path.join(HERE, "edge_results.json")
HOST = "hpc.uin-suka.ac.id"; WARM, ITERS = 30, 300
res = {"time": time.strftime("%Y-%m-%d %H:%M:%S"), "platform": platform.platform(), "cpu": platform.processor(),
       "python": platform.python_version(), "torch": torch.__version__, "timm": timm.__version__,
       "cuda": torch.cuda.is_available(), "gpu": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
       "models": [], "preprocess": {}, "network": {}}
print(json.dumps({k: res[k] for k in ("platform", "cpu", "torch", "cuda", "gpu")}, indent=1), flush=True)

nv = None
try:
    import pynvml; pynvml.nvmlInit(); nv = pynvml.nvmlDeviceGetHandleByIndex(0)
    res["driver"] = pynvml.nvmlSystemGetDriverVersion()
except Exception as e:
    res["nvml_error"] = str(e)

def power_w():
    return pynvml.nvmlDeviceGetPowerUsage(nv) / 1000.0

class Sampler:
    def __init__(self): self.v, self.stop = [], False
    def run(self):
        while not self.stop:
            try: self.v.append(power_w())
            except Exception: pass
            time.sleep(0.01)

def idle_power():
    if nv is None: return None
    torch.cuda.synchronize(); time.sleep(2); s = []
    for _ in range(100): s.append(power_w()); time.sleep(0.01)
    return statistics.mean(s)

def bench(name, dev, bs):
    m = timm.create_model(name, pretrained=False, num_classes=2).eval().to(dev).to(memory_format=torch.channels_last)
    dt = torch.float16 if dev == "cuda" else torch.float32
    m = m.to(dt); x = torch.randn(bs, 3, 224, 224, device=dev, dtype=dt).contiguous(memory_format=torch.channels_last)
    lat = []
    with torch.inference_mode():
        for _ in range(WARM): m(x)
        if dev == "cuda": torch.cuda.synchronize()
        p_idle = idle_power() if dev == "cuda" else None
        smp = Sampler(); th = threading.Thread(target=smp.run, daemon=True)
        if dev == "cuda" and nv is not None: th.start()
        t_all = time.perf_counter()
        for _ in range(ITERS):
            t = time.perf_counter(); m(x)
            if dev == "cuda": torch.cuda.synchronize()
            lat.append((time.perf_counter() - t) * 1000)
        t_all = time.perf_counter() - t_all; smp.stop = True
        if th.is_alive(): th.join()
    r = dict(model=name, device=dev, batch=bs, dtype=str(dt).split(".")[-1], p50_ms=float(np.percentile(lat, 50)),
             p95_ms=float(np.percentile(lat, 95)), img_per_s=bs * ITERS / t_all)
    if smp.v and p_idle is not None:
        p = statistics.mean(smp.v); r.update(gpu_power_w=p, gpu_idle_w=p_idle, gpu_energy_mj_per_img=(p - p_idle) * t_all / (bs * ITERS) * 1000)
    if dev == "cuda": r["gpu_mem_mb"] = torch.cuda.max_memory_allocated() / 2**20; torch.cuda.reset_peak_memory_stats()
    print(r, flush=True); return r

devs = (["cuda"] if torch.cuda.is_available() else []) + ["cpu"]
for dev in devs:
    if dev == "cpu": torch.set_num_threads(max(1, (os.cpu_count() or 4) // 2))
    for name in ("mobilenetv3_large_100", "resnet50"):
        for bs in (1, 8):
            res["models"].append(bench(name, dev, bs))

# preprocessing: JPEG decode + resize, as the edge would do per frame
rng = np.random.default_rng(0); img = Image.fromarray(rng.integers(0, 255, (256, 256, 3), dtype=np.uint8))
sizes = {}
for q in (95, 75):
    b = io.BytesIO(); img.save(b, "JPEG", quality=q); sizes[q] = len(b.getvalue())
b95 = io.BytesIO(); img.save(b95, "JPEG", quality=95); raw = b95.getvalue(); t = []
for _ in range(300):
    s = time.perf_counter(); Image.open(io.BytesIO(raw)).convert("RGB").resize((224, 224), Image.BICUBIC); t.append((time.perf_counter() - s) * 1000)
res["preprocess"] = dict(jpeg_decode_resize_p50_ms=float(np.percentile(t, 50)), jpeg_bytes_q95_noise=sizes[95], jpeg_bytes_q75_noise=sizes[75],
                         note="random-noise JPEG is a worst case; real 256x256 faces are ~15-25 kB at q95")

# network to the cluster portal (same campus network path the edge would use)
rtt = []
for _ in range(30):
    try:
        s = time.perf_counter(); c = socket.create_connection((HOST, 443), timeout=5); rtt.append((time.perf_counter() - s) * 1000); c.close()
    except Exception as e: res["network"]["tcp_error"] = str(e)
    time.sleep(0.1)
https = []
ctx = ssl.create_default_context()
for _ in range(10):
    try:
        s = time.perf_counter(); urllib.request.urlopen(f"https://{HOST}/", timeout=10, context=ctx).read(); https.append((time.perf_counter() - s) * 1000)
    except Exception as e: res["network"]["https_error"] = str(e)
if rtt: res["network"].update(tcp_connect_p50_ms=float(np.percentile(rtt, 50)), tcp_connect_p95_ms=float(np.percentile(rtt, 95)), n_tcp=len(rtt))
if https: res["network"].update(https_get_p50_ms=float(np.percentile(https, 50)), https_get_p95_ms=float(np.percentile(https, 95)), n_https=len(https))
with open(OUT, "w") as f: json.dump(res, f, indent=1)
print("\nEDGE_BENCH_OK ->", OUT, flush=True)
