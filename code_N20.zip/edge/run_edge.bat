@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"
echo === Benchmark edge (laptop) untuk cascade tersertifikasi ===
set "PY="
py -3 --version >nul 2>nul && set "PY=py -3"
if not defined PY python --version >nul 2>nul && set "PY=python"
if not defined PY (
  for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python3*") do if exist "%%D\python.exe" set "PY="%%D\python.exe""
)
if not defined PY if exist "%USERPROFILE%\anaconda3\python.exe" set "PY="%USERPROFILE%\anaconda3\python.exe""
if not defined PY if exist "%USERPROFILE%\miniconda3\python.exe" set "PY="%USERPROFILE%\miniconda3\python.exe""
if not defined PY if exist "C:\ProgramData\anaconda3\python.exe" set "PY="C:\ProgramData\anaconda3\python.exe""
if not defined PY (
  echo Python tidak ditemukan di laptop ini.
  echo Pasang Python 3.11 dari https://www.python.org/downloads/ dan centang "Add Python to PATH", lalu jalankan lagi.
  pause & exit /b 1
)
echo Python ditemukan: !PY!
!PY! --version
if not exist .venv !PY! -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
python -c "import torch,sys; sys.exit(0 if torch.cuda.is_available() else 1)" 2>nul || python -m pip install torch torchvision --index-url https://download.pytorch.org/whl/cu121
python -m pip install timm nvidia-ml-py pillow numpy
python edge_bench.py
echo.
echo Selesai. Hasil: %~dp0edge_results.json
pause
